class Test {
	static int count = 0;
	String name;

	public static void check() {
		System.out.println("Test class - Check ");
	}
	public void m1() {
		
		System.out.println("m1 of Test");
	}

	public void m2() {
		System.out.println("m2 of Test");
	}
}

public class Lab6 {
	public static void main(String[] args) {
		Test.check();
		Test test = new Test();
		test.m1();
		test.m2();
	}
}
