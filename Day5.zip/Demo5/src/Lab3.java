 abstract class Emp{
	private int empno;
	private String ename;
	private double salary;
	public abstract void calcSalary();
}
// no instance of this class can be created
class ContractEmp extends Emp{

	@Override
		public void calcSalary() {
			System.out.println("ContractEmp calcSalary invoked...");
	}
}
class PermEmp extends Emp{

	@Override
	public void calcSalary() {
		System.out.println("PermEmp calcSalary invoked...");
	}
	
}

public class Lab3 {
public static void main(String[] args) {
//	Emp e1 = new Emp();
	ContractEmp e2 = new ContractEmp();
	e2.calcSalary();
	PermEmp e3 =  new PermEmp();
	e3.calcSalary();
}
}
