interface Connection{
	public void open();
	public void close();
}
class OracleConnection implements Connection{

	@Override
	public void open() {
		System.out.println("OracleConnection - open method is invoked");
	}

	@Override
	public void close() {
		System.out.println("OracleConnection - close method is invoked");
	}
	
}
public class Lab5 {
	public static void main(String[] args) {
		Connection con = new OracleConnection();
		con.open();
		con.close();
	}
}
