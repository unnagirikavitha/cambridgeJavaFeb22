class SimpleOverloading {
	// Method Overloading
	public void add(int i, int j) {
		System.out.println("Sum  = " + (i+j));
	}
	public void add(int i, int j, int k) {
		System.out.println("Sum =  " + (i+j+k));
	}
}
public class Lab2 {
	public static void main(String[] args) {
		SimpleOverloading so = new SimpleOverloading();
		so.add(100, 200);
		so.add(100,200,300);
	}
}
