import java.util.Scanner;

public class Lab8 {
	public static void main(String[] args) {
		Scanner scanner =null;
		try {
			scanner =  new Scanner(System.in);
			System.out.print("Enter a String  1 : ");
			String no1str = scanner.next();
			System.out.print("Enter String 2 : ");
			String no2str = scanner.next();
			int no1 = Integer.parseInt(no1str);
			int no2 = Integer.parseInt(no2str);
			System.out.println("Sum = " + (no1 + no2));
			System.out.println("Division  = " + ((double)no1 / no2));
		} catch (NumberFormatException e) {
			System.out.println("Please enter numeric data");
		} catch (ArithmeticException e) {
			System.out.println("Second parameter must be nonzero");
		} finally {
			scanner.close();
		}
	}
}
