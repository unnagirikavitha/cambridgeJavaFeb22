import java.util.HashMap;
import java.util.Map;

public class Lab6 {

	public static void main(String[] args) {
			Map<String, Integer> map = new HashMap<String, Integer>();
			map.put("Seema", 70);
			map.put("Amit", 80);
			map.put("Amin", 82);
			System.out.println(map);
			map.put("Seema",99);
			map.put("Keshor",67);
			System.out.println(map);
			System.out.println("Value for Amin is "+ map.get("Amin"));
	}

}
