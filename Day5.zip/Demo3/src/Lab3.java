import java.util.Arrays;
import java.util.Scanner;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter a number (size of array) : ");
		int size = scanner.nextInt();
		int[] intarr = new int[size];
		System.out.println(Arrays.toString(intarr));
		for(int i =0;i<intarr.length; i++) {
			intarr[i]=(int)(Math.random()*100);
			System.out.println("Current i = " + i + ", Value = " + intarr[i]);
		}
	}
}
