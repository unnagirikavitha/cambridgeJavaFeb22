
public class Lab3 {
	public static void main(String[] args) {
		Emp e1 = new Emp(1, "Sarita", 100.00);
		System.out.println(e1);
		e1.incrSalary();
		System.out.println(e1);
		e1.incrSalary(10);
		System.out.println(e1);
		
		e1.setEname("Simantini");
		System.out.println(e1);
		
	}
}
