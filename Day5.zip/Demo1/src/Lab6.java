public class Lab6{

     public static void main(String []args){
	int count = 13;
    	System.out.println("Current Value = " + count);
	for(int i = 0; i< count;i++){
		System.out.println("Current i = "+ i);
	}
	}
}