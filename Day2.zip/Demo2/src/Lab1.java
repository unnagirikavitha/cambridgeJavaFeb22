import java.util.Scanner;
public class Lab1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Please enter your name : ");
		String name = scanner.next();
		
		System.out.print("Please enter your marks : ");
		int marks = scanner.nextInt();
		System.out.println("Your Name is " + name +  " and marks are " + marks);
		if (marks >= 35 )
			System.out.println("Status = Pass");
		else
			System.out.println("Status = Fail");
	}

}
