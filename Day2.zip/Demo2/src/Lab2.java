import java.util.Scanner;

import maths.Calc;

public class Lab2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Number 1 : ");
		int no1 = scanner.nextInt();
		System.out.print("Enter Number 2 : ");
		int no2 = scanner.nextInt();
		
		Calc c1 = new Calc();
		int sum = c1.add(10, 20);
		System.out.println("Sum of 10 and 20 is " + sum);
		sum = c1.add(no1,  no2);
		System.out.println("Sum of " + no1 + " and " + no2 + " is " + sum);
		
	}

}
