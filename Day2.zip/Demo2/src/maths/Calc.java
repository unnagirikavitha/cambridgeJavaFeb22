package maths;

public class Calc {
	//Methods
	public int add(int no1, int no2) {
		return no1+no2;
	}
}
