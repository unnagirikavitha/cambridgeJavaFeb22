class Lab2{
public static void main(String[] args){
	String name = "aaa";
	int marks = 20;
	System.out.println("Name = " + name  + ", Marks = " + marks);
}
}