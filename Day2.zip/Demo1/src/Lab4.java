public class Lab4{

     public static void main(String []args){
        int num= 20;
       	if ((num%2)==0){
		System.out.println("Number is Even");
		System.out.println("Some description of even numbers");
		}
	else
		System.out.println("Number is Odd");
     }
}