public class Lab5{

     public static void main(String []args){
      String name = "aaaaaaa";
	
    System.out.println("Length = " + name.length() );
 
switch (name.length()) {
  case 1:
  case 2:
  case 3:
  case 4: 
  case 5:
    System.out.println("Length is less than or equal to 5 which means small name ");
    break;
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
	    System.out.println("Lenght is greater than 5 and less than or equal to 10, which means mid size name");
    break;
}
//--------------------------------------------
if (name.length() <= 5)
	  System.out.println("Length is less than or equal to 5 which means small name ");
else if (name.length() <= 10)
	 System.out.println("Lenght is greater than 5 and less than or equal to 10, which means mid size name"); 
}
}