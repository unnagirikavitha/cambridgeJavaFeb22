package maths;

public class Calc {
	
	public void dosomething() {
		System.out.println("In Calc dosomething is invoked...");
	}
	//Methods
	public int add(int no1, int no2) {
		System.out.println("in calc add with " + no1 + ", " + no2);
		int ans = no1+no2;
		System.out.println("In calc ans = " + ans);
		return ans;
	}
	public int sub(int no1, int no2) {
		return no1-no2;
	}
}
