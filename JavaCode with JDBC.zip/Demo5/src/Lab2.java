import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class Student{
	 private String studentName;
	 private int marks;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", marks=" + marks + "]";
	}
	 
}

/*
. Define class School
  List<Student> list = new ArrayList<Student>();
  write a for loop to add 4 students 
    -> just show list
*/    
public class Lab2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		List<Student> list = new ArrayList<Student>();
		for (int i = 0;i<5;i++) {
			System.out.println("Enter Student Name : ");
			Student std1 = new Student();
			std1.setStudentName(scanner.next());
			System.out.println("Enter Marks : ");
			std1.setMarks(scanner.nextInt());
			list.add( std1);
		}
		for(int i = 0;i< list.size();i++)
			System.out.println(list.get(i));
	//	System.out.println(list);
	}

}
