
final class BusinessLogic{

	 final public void m1() {
		 System.out.println("BusinessLogic m1 method...");
	 }
}
//class MyCode extends BusinessLogic{
/*		public void m1() {
	System.out.println("MyCode overrides m1 method");
	}*/
//}
class Lab4{
	public static void main(String[] args) {
		BusinessLogic logic1 = new BusinessLogic();
		logic1.m1();
	//	MyCode mycode =new MyCode();
	//	mycode.m1();
	}
}