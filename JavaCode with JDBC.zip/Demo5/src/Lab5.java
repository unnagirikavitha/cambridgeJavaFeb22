class Simple {
	static int count = 0;
	String name;

	public Simple(String name) {
		count++;
		this.name = name;
	}

}

public class Lab5 {
	public static void main(String[] args) {
		Simple s1 = new Simple("first");
		System.out.println(s1.name);
		Simple s2 = new Simple("second");
		System.out.println(s2.name);
		Simple s3 = new Simple("third");
		System.out.println(s3.name);
		System.out.println("Current Value of Count = " + Simple.count);

	}
}
