import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		List<String> list = new ArrayList<String>();
		for (int i = 0;i<5;i++) {
			System.out.println("Enter a String : ");
			list.add( scanner.next());
		}
		System.out.println(list);
		System.out.println("Enter the String which you want to remove");
		list.remove(scanner.next());
		
		System.out.println(list);
	}

}
