class Lab2Support1 extends Thread {
	
	public void run() {
		System.out.println("Executing in Thread " + Thread.currentThread().getName());
		for(int i = 0;i < 100;i++) {
			System.out.println("Value of i = " + i +" in thread " + Thread.currentThread().getName());
		}
	}
}
public class Lab2 {
	public static void main(String[] args) {
		
		System.out.println("in Main, executing in Thread " + Thread.currentThread().getName());
		System.out.println("111");
		Lab2Support1 s1 = new Lab2Support1();
		Lab2Support1 s2 = new Lab2Support1();
		s1.start();
		s2.start();
		System.out.println("End of Main");
		
	}
}
