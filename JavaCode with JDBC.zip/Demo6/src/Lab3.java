import java.util.ArrayList;
import java.util.List;

class Lab3Support extends Thread {
	private List<String> list;

	public Lab3Support(List<String> list) {
		this.list = list;
	}

	@Override
	public void run() {
		for (int i = 0; i < 100; i++) {
			synchronized (list) {
				list.add("str" + i);
			}

		}
		System.out.println("Size of List = " + list.size());
	}

}

public class Lab3 {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		Lab3Support t1 = new Lab3Support(list);
		Lab3Support t2 = new Lab3Support(list);
		t1.start();
		t2.start();

	}
}
