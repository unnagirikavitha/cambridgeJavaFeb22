import java.util.Scanner;

class Helper extends Thread{
	private String name;
	public Helper(String name) {
		this.name = name;
	}

	public void run() {
		for (int i = 0; i< 9999000;i++) {
			System.out.print(name);
		}
	}
}
public class Lab1 {
	public static void main(String[] args) {
		System.out.println("Enter a number to continue..");
		Scanner scanner  = new Scanner(System.in);
		scanner.nextInt();
		Helper h1 = new Helper("-");
		Helper h2= new Helper("*");
		Helper h3= new Helper("o");
		Helper h4= new Helper("x");
		
		h1.start(); // create a new thread and invoking run method
		h2.start(); // create a new thread and invoking run method
		h3.start();
		h4.start();
		//h1.run();
		//h2.run();
	
	}
}
