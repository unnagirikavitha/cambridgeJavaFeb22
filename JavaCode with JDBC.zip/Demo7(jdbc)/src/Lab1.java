import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Lab1 {
	
	// create a table in hsqldb
public static void main(String[] args)  {

	try {
		Class.forName("org.hsqldb.jdbcDriver");
		System.out.println("class.forName successful");
		Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/","SA","");
		System.out.println("Connection established...");	
		Statement  stmt = con.createStatement();
		stmt.execute("create table dept (deptno numeric primary key, dname varchar(10), loc varchar(10))");
		System.out.println("Create table successful");

	} catch (Exception e) {
			System.out.println(e);
	}

}
}
