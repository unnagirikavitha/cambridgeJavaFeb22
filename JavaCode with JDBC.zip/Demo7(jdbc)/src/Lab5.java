import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Lab5 {
	
	// update a row in table 
public static void main(String[] args)  {
	Connection con = null;
	Statement stmt = null;
	try {
		Class.forName("org.hsqldb.jdbcDriver");
		con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/","SA","");
		stmt = con.createStatement();
		Scanner scanner = new Scanner(System.in);
		stmt.execute("UPDATE dept SET dname= 'bbbb' WHERE deptno = 20");
		System.out.println("Updated");
	} catch (Exception e) {
			System.out.println(e);
	}finally {
		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
}
