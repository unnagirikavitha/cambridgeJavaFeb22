import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Lab4 {
	
	// delete a row in table 
public static void main(String[] args)  {
	Connection con = null;
	Statement stmt = null;
	try {
		Class.forName("org.hsqldb.jdbcDriver");
		con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/","SA","");
		stmt = con.createStatement();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Department Details to delete");
		System.out.print("Deptno : ");
		int deptno = scanner.nextInt();
		stmt.execute("DELETE FROM dept WHERE deptno="+ deptno);
		System.out.println("Deleted");
	} catch (Exception e) {
			System.out.println(e);
	}finally {
		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
}
