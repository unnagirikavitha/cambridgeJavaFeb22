import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Lab2 {
	
	// insert a row in table 
public static void main(String[] args)  {
	Connection con = null;
	Statement stmt = null;
	try {
		Class.forName("org.hsqldb.jdbcDriver");
		con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/","SA","");
		stmt = con.createStatement();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Department Details");
		System.out.print("Deptno : ");
		int deptno = scanner.nextInt();
		System.out.print("Dname : ");
		String dname=scanner.next();
		System.out.print("Loc : ");
		String loc = scanner.next();
		stmt.execute("INSERT INTO dept VALUES ("+deptno+", '" + dname +"', '"+loc+"')");
		System.out.println("Inserted");
	} catch (Exception e) {
			System.out.println(e);
	}finally {
		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
}
