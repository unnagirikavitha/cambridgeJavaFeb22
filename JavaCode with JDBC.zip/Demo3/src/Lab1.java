import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) {
		int no1 =10;
		System.out.println("Number 1 =  " + no1);
	//	int[] arr = new int[5];
		int[] arr =  {10,20,40,60,70,400};
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);
		for (int i = 0;i<arr.length;i++) {
			System.out.println("In For, current i = " + i + " value of arr = " + arr[i]);
		}
		
		int i = 0;
		while (i < arr.length) {
			System.out.println("In While, current i = " + i + " value of arr = " + arr[i]);
			i++;
		}
		
		
			
	}

}
