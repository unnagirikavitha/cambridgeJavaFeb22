class Base{
	public void m1() {
		System.out.println("Base Method - m1");
	}
}

class Derived extends Base{
	
	  @Override public void m1() { System.out.println("Derived Method - m1"); }
	 
}
public class Lab8 {
	public static void main(String[] args) {
		Base b1 =new Base();
		b1.m1();
		Derived d1 = new Derived();
		d1.m1();
	}
}
