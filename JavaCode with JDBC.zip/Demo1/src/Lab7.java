public class Lab7{

     public static void main(String []args){
	int count = 20;
	while(count > 10){
		System.out.println("count is less than 10");
		// count = count  - 1 
		count--;
	}
}
}