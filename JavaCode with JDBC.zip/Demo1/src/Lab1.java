class Lab1
{
 public static void main(String[] args){
		String firstname ="Vaishali";
		String lastname = "Tapaswi";
		String name = firstname + "  " + lastname;
		System.out.println("Hello World - Lab1");
		System.out.println(name);
}
}