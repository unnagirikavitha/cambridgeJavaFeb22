public class Lab3{

     public static void main(String []args){
        String name  = "Seema";
        int marks = 20;
        if (marks >= 35)
            System.out.println("Student Name " + name + ", status is PASS" );
        else
            System.out.println("Student Name " + name + ", status is FAIL" );
            
     }
}