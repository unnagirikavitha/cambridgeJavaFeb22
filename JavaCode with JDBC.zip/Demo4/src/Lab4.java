import java.util.Scanner;

class Rectangle {
	private int width;
	private int length;

	@Override
	public String toString() {
		return "Rectangle [width=" + width + ", length=" + length + "]";
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public void draw() {
		System.out.println("Drawing a rectangle with Length = " + length + " and width = " + width);
	}
}

class ColourRectangle extends Rectangle
{
 private String colour;
 
 public String getColour() {
	return colour;
}

public void setColour(String colour) {
	this.colour = colour;
}

@Override
 public void draw ()
  {
	 System.out.println("Drawing a "   +colour + " rectangle with Length = " + getLength() + " and width = " + getWidth());
  }
}
public class Lab4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Length of Rectangle : ");
		Rectangle rect = new Rectangle();
		rect.setLength(scanner.nextInt());
		System.out.print("Enter Width of Rectangle : ");
		rect.setWidth(scanner.nextInt());

		rect.draw();
		System.out.println("Enter the details for Coloured Rectangle");
		System.out.print("Enter Length of Rectangle : ");
		ColourRectangle rect1 = new ColourRectangle();
		rect1.setLength(scanner.nextInt());
		System.out.print("Enter Width of Rectangle : ");
		rect1.setWidth(scanner.nextInt());
		System.out.print("Enter Colour of Rectangle");
		rect1.setColour(scanner.next());
		rect1.draw();
		
		
	}
}
