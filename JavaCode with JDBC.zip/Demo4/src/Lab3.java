class Parent{
	private String sirname;

	@Override
	public String toString() {
		return "Parent [sirname=" + sirname + "]";
	}
	public String getSirname() {
		return sirname;
	}
	public void setSirname(String sirname) {
		this.sirname = sirname;
	}
	
}

class Child extends Parent {
	// No OverRidden
	private String firstname;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	@Override
	public String toString() {
		System.out.println(super.toString());
		return "Child [firstname=" + firstname + "]";
	}
	
}


public class Lab3 {

	public static void main(String[] args) {
		/*
		 * Parent p1 = new Parent(); p1.setSirname("Ayangar"); System.out.println(p1);
		 */
		Child c1 = new Child();
		c1.setSirname("Ayangar");
		c1.setFirstname("Alee");
		System.out.println(c1);
	}

}
