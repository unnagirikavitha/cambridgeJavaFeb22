import java.util.Scanner;

public class Lab6 {
	public static void main(String[] args) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter Number 1 : ");
			int no1 = scanner.nextInt();
			System.out.print("Enter Number 2 : ");
			int no2 = scanner.nextInt();
			System.out.println("Sum = " + (no1 + no2));
			System.out.println("Division  = " + (no1 / no2));
		} catch (Exception e) {
			System.out.println("Some Error has occurred.... " +e );
		}
	}
}
