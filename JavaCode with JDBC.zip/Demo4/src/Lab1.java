//POJO - Plain Old Java Object
class Dept{
	private int deptno;
	private String dname;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + "]";
	}
	
}
public class Lab1 {

	public static void main(String[] args) {
			Dept d = new Dept();
			d.setDeptno(10);
			d.setDname("HR");
			System.out.println(d);
	}

}
